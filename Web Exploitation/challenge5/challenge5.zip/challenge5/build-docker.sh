docker build . -t very-easy-sqli
docker run -it -p 3000:3000 very-easy-sqli
